import React, { Component } from 'react';

const Tabs = ()=> {
    <div>
        <input/>
        <button>

        </button>
    </div>


    }
    export default Tabs;
    /*createLi () {

    };


    render() {
        return (
            <div>
                <input/>
                    <button onClick = {this.createLi.bind(this)} >

                    </button>
            </div>

        )
    };
}


export default Tabs; */