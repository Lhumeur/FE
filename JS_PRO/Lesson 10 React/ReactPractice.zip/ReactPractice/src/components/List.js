import React, { Component } from 'react';
import Tabs from './components/Tabs';
import App from "./components/App";

class List  extends Component {
    constructor() {
        super();
    }
    render() {
        return (
            <ul>

            </ul>
        )
    }
}


export default App;