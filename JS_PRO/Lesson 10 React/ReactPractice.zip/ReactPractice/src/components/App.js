import React, { Component } from 'react';
import Tabs from './components/Tabs';
import List from "./components/List";

class App extends Component {
   constructor (){
       super();

      // this.state = { items : []};
   }

    /*createLi () {


   }*/


    render () {
        return (
            <div>
                <Tabs />
                <List />

            </div>
        );
    }
}


export default App;