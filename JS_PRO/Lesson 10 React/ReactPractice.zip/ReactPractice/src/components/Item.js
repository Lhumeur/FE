import React, { Component } from 'react';
import Tabs from './components/Tabs';
import App from "./components/App";

const onClick = function () {

};


const Item = props => <div> <li>props.value</li> <button onClick = {} > X </button></div>;

export default Item;