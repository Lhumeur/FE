export const parsing = (list) => {
    const weatherWeek = [];
    let currentDay = null;
    let tempDay = 0;
    let tempNight = 0;







    for (const item of list) {
        const date = new Date(item.dt * 1000);
        const day = date.getUTCDay();
        const hour = date.getHours();

        // if (hour > 6 && hour < 21) {
        //     if (item.main.temp > tempDay){
        //         tempDay = item.main.temp;
        //     }
        // } else {
        //     if (item.main.temp < tempDay){
        //         tempNight = item.main.temp;
        //     }
        // }

        if (currentDay !== day) {
            weatherWeek.push({
                day: parseDays(day),
                tempDay,
                tempNight
            });

            currentDay = day;
        }
    }

    
console.log({
    list
})

    console.log({
        weatherWeek
    })
};

const parseDays = (param) => {
    switch (param) {
        case 0: {
            return "Воскресенье";
        }
        case 1: {
            return "Понедельник";
        }
        case 2: {
            return "Вторник";
        }
        case 3: {
            return "Среда";
        }
        case 4: {
            return "Четверг";
        }
        case 5: {
            return "Пятница";
        }
        case 6: {
            return "Суббота";
        }
    }
}