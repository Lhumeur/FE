import React, { Component } from 'react';

import {parsing} from "./service";
import {AppRouting} from "./ExampleRouting";

class App extends Component {

  async componentDidMount() {
    const promise = await fetch('http://api.openweathermap.org/data/2.5/forecast?id=625144&APPID=a37702eff2a86bd07c142b1910ae9df4&units=metric');
    const {list} = await promise.json();
    parsing(list);

  }

  render() {
    return (
      <AppRouting />
    );
  }
}

export default App;
