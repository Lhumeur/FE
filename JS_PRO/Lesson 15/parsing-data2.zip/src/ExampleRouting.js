import React from "react";
import { BrowserRouter as Router, Link, Route } from "react-router-dom";

const Home = () => {
    return (
        <h1>Home</h1>
    );
};

const News = () => {
    return (
        <h1>News</h1>
    );
};

const Mails = () => {
    return (
        <h1>Mails</h1>
    );
};


export const AppRouting = () => {
    return (
        <Router>
            <div>
            <div>
                <Link to="/">Home</Link>
                <Link to="/news">News</Link>
                <Link to="/mails">Mails</Link>
            </div>
            <div>
                <Route exact path="/" component={Home} />
                <Route path="/news" component={News} />
                <Route path="/mails" component={Mails} />
            </div>
            </div>
        </Router>
    );
};