export const parsing = (list) => {
    const date = new Date(list[0].dt_txt);
    const today = date.getUTCDay();
    let itemsForCurrentDay = 0;

    const weatherWeek = [];
    const weatherOnDay = [];
    let tempDay = 0;
    let tempNight = 0;
    let temp = 0;

    for (let i = 0; i < list.length; i++) {
        const date = new Date(list[i].dt_txt);
        const day = date.getUTCDay();
        const hour = date.getHours();

        if (today !== day) {
            temp += list[i].main.temp;
            itemsForCurrentDay++;

            if (itemsForCurrentDay === 8 || i === list.length - 1) {
                temp = temp / itemsForCurrentDay;

                weatherWeek.push({
                    day: parseDays(day),
                    temp
                });

                itemsForCurrentDay = 0;
                temp = list[i].main.temp;
            }
        }

        if (weatherOnDay.length !== 24) {
            getDataForOneDay(weatherOnDay, list[i].main.temp, hour);
        }
    }
};

const getDataForOneDay = (array, temp, hour) => {
    for (let i = 0; i < 3; i++) {
        array.push({
            time: `${hour + i}:00`,
            temp: temp
        });
    }
};

const parseDays = (param) => {
    switch (param) {
        case 0: {
            return "Воскресенье";
        }
        case 1: {
            return "Понедельник";
        }
        case 2: {
            return "Вторник";
        }
        case 3: {
            return "Среда";
        }
        case 4: {
            return "Четверг";
        }
        case 5: {
            return "Пятница";
        }
        case 6: {
            return "Суббота";
        }
    }
};